/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.prj301.shopping;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import pe.prj301.utils.DBUtils;

/**
 *
 * @author hd
 */
public class DAO {

    public ArrayList<Products> getAllProduct() throws ClassNotFoundException {
        DBUtils dbu = new DBUtils();
        ArrayList<Products> list = new ArrayList<>();
        try {
            Connection connection = dbu.getConnection();
            String sql = "SELECT [productID]\n"
                    + "      ,[productName]\n"
                    + "      ,[description]\n"
                    + "      ,[price]\n"
                    + "      ,[status]\n"
                    + "  FROM [dbo].[tblProducts]\n"
                    + "  where status = 1";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Products dto = new Products(rs.getString("productID"), rs.getString("productName"), rs.getString("description"), rs.getInt("price"), rs.getBoolean("status"));
                list.add(dto);
            }
        } catch (SQLException e) {
            System.out.println("Error list Food");
        }
        return list;
    }
}
